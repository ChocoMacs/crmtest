#!/usr/bin/python2.7
# -*-coding:utf-8 -*

import json
import urllib
import urllib2
import ssl
import os
import argparse
import shutil
import md5
import time
import time
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("-d", "--dev", action="store_true", help="Dev mode")
parser.add_argument("-v", "--verbose", action="store_true", help="Increases verbosity")
args = parser.parse_args()

# =================================
# CONFIGURATION
# =================================
url = 'https://location-url/'
ftpDir = "/home/ftp"
technicalManagerRelativeDir = "/technical_manager"
staffRelativeDir = "/staff"
orderRelativeDir = "/orders"
uidWrite = 2003
uidRead = 2002
gid = 2001
# =================================
# END
# =================================

def umountFolder(path):
    # On demonte le dossier autant de fois que necessaire
    p = subprocess.Popen('findmnt '+path+' > /dev/null && (umount -l '+path+' && echo umount)', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if(len(p.stdout.readlines())):
        umountFolder(path)
    retval = p.wait()

def removeFolder(path):

    # On verifie l'absense de montage du dossier
    umountFolder(path)

    # On verifie l'absense de montage dans ce dossier
    for dossier, sous_dossiers, fichiers in os.walk(path):
        for toUmount in sous_dossiers:
            # Si monte, on demonte le dossier
            umountFolder(dossier+'/'+toUmount)

    # Puis suppression du dossier
    shutil.rmtree(path)

url += 'ftp-api'

if (args.verbose and args.dev):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Sync in dev mode')
elif (args.verbose):
    print(str(time.strftime("%b %d-%d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Sync in prod mode')

try:

    data = {}

    if (args.verbose):
        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Call url : '+url+' with args :')
        print(data)

    request = urllib2.Request(url, data = urllib.urlencode(data), headers = {"Accept": "*/*", "User-Agent": "MyCMP/FTP"})
    response = urllib2.urlopen(request, context=ssl._create_unverified_context())

    res = response.read()
    response.close()
    res = json.loads(res)

except urllib2.HTTPError as error:
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' ERROR : '+str(error))

if (args.verbose):
        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Step 1 : Check technical managers homedir')

try:
    res['technicalManagerAccount']
except KeyError:
    res['technicalManagerAccount'] = []

if (args.verbose):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Get a total of '+str(len(res['technicalManagerAccount']))+' homedir')

# Created the homedir not exist
nbCreated = 0
nbMaintained = 0
for home in res['technicalManagerAccount']:
    dir = ftpDir+technicalManagerRelativeDir+'/'+home
    # If homedir does not exist
    if (os.path.isdir(dir) == False):
        if (args.verbose):
            print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Create technical manager homedir : '+dir)
        os.mkdir(dir)
        nbCreated += 1
        os.chown(dir, uidRead, gid)
    else:
        nbMaintained += 1

# Remove the homedir not in list
nbRemoved = 0
for dirname in os.listdir(ftpDir+technicalManagerRelativeDir):
    if ((dirname in res['technicalManagerAccount']) == False):
        dir = ftpDir+technicalManagerRelativeDir+'/'+dirname
        removeFolder(dir)
        nbRemoved += 1
        if (args.verbose):
            print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Remove technical manager homedir : '+dir)

if (args.verbose):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbCreated)+' technical manager homedir created')
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbMaintained)+' technical manager homedir maintained')
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbRemoved)+' technical manager homedir removed')

if (args.verbose):
        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Step 2 : Check mount point of Design Kit')

try:
    res['designKitAccess']
except NameError:
    res['designKitAccess'] = []


nbAccess = 0

if (len(res['designKitAccess'])):
    for technicalManagerAccount, technicalManagerAccess in res['designKitAccess'].items():
        for dkAccess in technicalManagerAccess:
            nbAccess += 1

if (args.verbose):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Get a total of '+str(nbAccess)+' design kit access')

# Created the dkAccess not exist
nbCreated = 0
nbRemoved = 0
nbMaintained = 0

if (len(res['designKitAccess'])):
    for technicalManagerAccount, technicalManagerAccess in res['designKitAccess'].items():

        dkDir = ftpDir+technicalManagerRelativeDir+'/'+technicalManagerAccount+'/DesignKits/'
        if os.path.isdir(dkDir) == False:
            os.makedirs(dkDir)


        for technology in os.listdir(dkDir):
            if os.path.isdir(dkDir+'/'+technology):
                for dk in os.listdir(dkDir+'/'+technology):
                    if os.path.isdir(dkDir+'/'+technology+'/'+dk):
                        toRemove = True
                        for dkAccess in technicalManagerAccess:
                            if (technology in dkAccess.values() and dk in dkAccess.values()):
                                toRemove = False
                        if (toRemove):
                            removeFolder(dkDir+technology+'/'+dk)
                            nbRemoved += 1
                            if (args.verbose):
                                print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Account "'+technicalManagerAccount+'" : Remove design kit point '+technology+'/'+dk)
                    else:
                        removeFolder(dkDir+'/'+technology+'/'+dk)
                        if (args.verbose):
                            print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Account "'+technicalManagerAccount+'" : Remove undesirable file "'+dkDir+technology+'/'+dk+ '"')
                toRemove = True
                for dkAccess in technicalManagerAccess:
                    if (technology in dkAccess.values()):
                        toRemove = False
                if (toRemove):
                    removeFolder(dkDir+technology)
                    if (args.verbose):
                        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Account "'+technicalManagerAccount+'" : Remove technology point '+technology)
            else:
                removeFolder(dkDir+technology)
                if (args.verbose):
                    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Account "'+technicalManagerAccount+'" : Remove undesirable file "'+dkDir+technology+ '"')


        for dkAccess in technicalManagerAccess:
            toMount = ftpDir+staffRelativeDir+dkAccess['path']
            if (os.path.exists(toMount)):
            	os.system('chown -R '+str(uidWrite)+':'+str(gid)+' '+toMount)
                destinationDir = dkDir+dkAccess['technology']+'/'+dkAccess['version']
                if (os.path.exists(destinationDir) == False):
                    os.makedirs(destinationDir)
                    if (args.verbose):
                        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Account "'+technicalManagerAccount+'" : Create design kit point "'+dkAccess['technology']+'/'+dkAccess['version'])
                    nbCreated += 1
                else:
                    umountFolder(destinationDir)
                    if (args.verbose):
                        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Account "'+technicalManagerAccount+'" : Refresh design kit point "'+dkAccess['technology']+'/'+dkAccess['version'])
                    nbMaintained += 1

                os.system('chown -R '+str(uidWrite)+':'+str(gid)+' '+dkDir)
                os.system('mount --bind '+(toMount.replace(" ", "\ "))+' '+destinationDir)
            else:
                os.makedirs(toMount)
                os.system('chown -R '+str(uidWrite)+':'+str(gid)+' '+toMount)

if (args.verbose):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbCreated)+' mount points created')
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbMaintained)+' mount points maintained')
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbRemoved)+' mount points removed')

nbCreated = 0

try:
    res['orderCircuit']
except NameError:
    res['orderCircuit'] = []

if (args.verbose):
        print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Step 3 : Check mount point for order')
if (args.verbose):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' Get a total of '+str(len(res['orderCircuit']))+' order')

if (len(res['orderCircuit'])):
    for run, allPrefix in res['orderCircuit'].items():

        orderRunDir = ftpDir + orderRelativeDir + '/' + run

        for prefix in allPrefix:
            orderRunPrefixDir = orderRunDir + '/' + prefix
            if os.path.isdir(orderRunPrefixDir) == False:
                os.makedirs(orderRunPrefixDir)
                nbCreated += 1

        os.system('chown -R ' + str(uidWrite) + ':' + str(gid) + ' ' + orderRunDir)

if (args.verbose):
    print(str(time.strftime("%b %d %H:%M:%S"))+' ftp-sync '+os.getlogin()+' '+str(nbCreated)+' order homedir created')