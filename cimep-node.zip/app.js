const config = require('./config.json');
const ent = require('ent');
const sha1 = require('sha1');
const fs = require('fs');

const server = config.ssl
    ? require('https').createServer({
        key: fs.readFileSync(config.ssl_key),
        cert: fs.readFileSync(config.ssl_crt)
    })
    : require('http').createServer();

const io = require('socket.io')(server);

function authMainServer(ip, password) {
    if (config.serveur_ip && ip !== config.serveur_ip) {
        log('warning', 'An unauthorized server tries to use the socket from ' + ip);
        return false;
    } else if (password && config.password !== password) {
        log('error', 'Main server bad credentials from ' + ip);
        return false;
    }
    return true;
}

function log(level, message) {
    const levels = { 'debug': 5, 'info': 4, 'warning': 3, 'error': 2, 'critical': 1 };
    if (level in levels && config.verbose in levels && levels[config.verbose] >= levels[level])
        console.log((new Date().toString()) + ' - ' + level + ' : ' + message);
}

io.on('connection', (socket) => {
    log('debug', 'New connection from ' + socket.handshake.address);

    socket.emit('need_register');

    /* =========================
           SERVEUR => CLIENT
       ========================= */

    // Processing notifications sent by the main server to the relevant client
    socket.on('notify', (data) => {
        // If the authenticating main server is the sender
        if (authMainServer(socket.handshake.address, data.password)) {
            io.to(data.token).emit('notify', data.args);
            log('info', 'New notification for token "' + data.token + '" from an authenticated server ' + socket.handshake.address);
        }
    });

    // Refresh the notification area on all clients using the token
    socket.on('refresh_client_notif', (token) => {
        io.to(token).emit('refresh_client_notif');
    });

    // Refresh the talkers of clients if they are open
    socket.on('talker_refresh', (data) => {
        // If the authenticating main server is the sender
        if (authMainServer(socket.handshake.address, data.password)) {
            socket.broadcast.emit('talker_refresh', data.args);
            log('info', 'Talker refresh for all from an authenticated server ' + socket.handshake.address);
        }
    });

    // Refresh the talkers of clients if they are open
    socket.on('ticket_refresh', (data) => {
        // If the authenticating main server is the sender
        if (authMainServer(socket.handshake.address, data.password)) {
            socket.broadcast.emit('ticket_refresh', data.args);
            log('info', 'Ticket refresh for all from an authenticated server ' + socket.handshake.address);
        }
    });

    // Indicate to users if someone is writing a message
    socket.on('ticket_writing', (data) => {
        // If the authenticating main server is the sender
        if (authMainServer(socket.handshake.address, data.password)) {
            io.to(data.channel).emit('ticket_writing', data.args);
            log('info', 'Ticket writing for channel ' + data.channel + ' from an authenticated server ' + socket.handshake.address);
        }
    });

    // Indicate to users if someone stops writing a message
    socket.on('ticket_stop_writing', (data) => {
        // If the authenticating main server is the sender
        if (authMainServer(socket.handshake.address, data.password)) {
            io.to(data.channel).emit('ticket_stop_writing', data.args);
            log('info', 'Ticket stop writing for channel ' + data.channel + ' from an authenticated server ' + socket.handshake.address);
        }
    });

    // In case of a token change issued by the main server
    socket.on('change_token', (data) => {
        // If the authenticating main server is the sender
        if (authMainServer(socket.handshake.address, data.password)) {
            io.to(data.token).emit('change_token', { "new_token": data.args.new_token });
            log('info', 'Change token "' + data.token + '" to "' + data.args.new_token + '" from ' + socket.handshake.address);
        }
    });

    /* =========================
           CLIENT => SERVEUR
       ========================= */

    // Registering the client's token on connection
    socket.on('register', (token) => {
        socket.token = token;
        socket.join(token);
        socket.emit('register_success', token);
        log('info', 'Token "' + token + '" registered from ' + socket.handshake.address);
    });

    // Registering a new channel
    socket.on('registerChannel', (channel) => {
        socket.join(channel);
        log('info', 'Token "' + socket.token + '" registers channel "' + channel + '" from ' + socket.handshake.address);
    });

    socket.on('disconnect', () => {
        if (socket.token)
            log('info', 'Token "' + socket.token + '" unregistered from ' + socket.handshake.address);
        log('debug', 'Disconnect from ' + socket.handshake.address);
    });
});

server.listen(config.port, '0.0.0.0', () => {
    console.log(`Server listening on port ${config.port}`);
});